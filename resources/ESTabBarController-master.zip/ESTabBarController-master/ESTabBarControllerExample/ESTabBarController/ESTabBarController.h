//
//  ESTabBarController.h
//  ESTabBarController
//
//  Created by lihao on 2017/2/8.
//  Copyright © 2018年 Egg Swift. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ESTabBarController.
FOUNDATION_EXPORT double ESTabBarControllerVersionNumber;

//! Project version string for ESTabBarController.
FOUNDATION_EXPORT const unsigned char ESTabBarControllerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ESTabBarController/PublicHeader.h>


